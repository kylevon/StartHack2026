# Kickoff with Soony – onboarding notes

Date: 2026-11-11
Attendees: Jonas Lindqvist (CPO), Dr. Maren Vogt (Head of Procurement), Raj Patel (Logistics), us

## What they said

- Grand Heist 6 goes on sale on Sunday 22 November 2026 at 20:00. The date is fixed by retail and by 487,000 pre-orders. "Produced" means packed at the distribution center in Hamburg (DC-HAM).
- Two editions. Standard: game card, case, sleeve, leaflet. Collector's: numbered, 72,000 copies, all pre-ordered, with steel case, art book, poster and a statue.
- The developer finished the game master late. Programmed game cards only started arriving three weeks ago, so Hamburg packs until the last hour.
- Since the first game cards arrived it has been crisis mode: buyers chasing suppliers by phone every day, freight rebooked from sea to air and back, every shift packing whatever arrived that day. Maren: "We get through by working around problems, not by solving them. The team is exhausted."
- The last 20 % will have no buffer. Jonas: "One late pallet on launch weekend and fans who paid for a numbered Collector's Edition get nothing."
- Why us: no time for a tender or a big vendor project. They need help now, before the launch, not next quarter. Jonas: "We cannot afford a single surprise in the last days before the launch."
- Six suppliers, and procurement knows them through paper: contracts, order confirmations, delivery notes. Every supplier has its own folder now. "Half of what we know is in a PDF somebody scanned."
- SAP holds the purchase orders, nothing else. There are two exports because the interface changed in mid-2025.
- Maren: suppliers tell them about problems too late. "We find out at the dock."
- Raj: about 20 open shipments, tracked in a shared spreadsheet that is updated when someone remembers.
- Delivery notes are scanned by the receiving team in Hamburg. Receiving books what is on the paper.
- Suppliers write in their own language. Nobody in procurement reads Polish or Korean.
- The Category Lead for Collector's Items left in the summer. The position is open.

## Open questions we did not get to

- What does a missing copy cost on day one? (Maren: "ask me at the booth")
- Who signs off on air freight?
- Which parts have only one source?
- Why does the stock list show no lid magnets?

## Data they gave us

See the portal: one folder per supplier under `suppliers/`, Soony's own data under `soony/`. They warned us: "It is what it is."
